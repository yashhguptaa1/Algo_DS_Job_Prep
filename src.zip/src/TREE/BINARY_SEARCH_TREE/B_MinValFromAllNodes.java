package TREE.BINARY_SEARCH_TREE;

public class B_MinValFromAllNodes {
}
