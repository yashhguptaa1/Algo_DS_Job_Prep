package RECURSION.DivideAndConquer.BinarySearch;

public class BinarySearchBoolean {
}
