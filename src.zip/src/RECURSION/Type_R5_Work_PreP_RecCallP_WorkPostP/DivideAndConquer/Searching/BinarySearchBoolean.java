package RECURSION.Type_R5_Work_PreP_RecCallP_WorkPostP.DivideAndConquer.Searching;

public class BinarySearchBoolean {
}
