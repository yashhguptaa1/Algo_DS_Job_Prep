package RECURSION.Type_R4_SwappingArguments;

public class PrintAllPermutations {
}
