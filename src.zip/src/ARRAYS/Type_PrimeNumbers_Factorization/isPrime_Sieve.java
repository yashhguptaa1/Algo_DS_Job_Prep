package ARRAYS.Type_PrimeNumbers_Factorization;

public class isPrime_Sieve {
}
