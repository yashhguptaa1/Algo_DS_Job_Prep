package ARRAYS.Type_Partition_Solved_Unsolved;
import java.util.*;

public class BubbleSort {

    public static void bubbleSort(int[] arr) {
        int n = arr.length;

        //last part of subarray is the sorted segment
        //initially we compare and the largest element
        //bubbles to last subarray that is sorted
        for(int i = 0; i < n - 1; i++) {
            //since n-i is the last subarray that is sorted
            //we dont need to make comparisons in next iteration in that subarray
            for(int j = 1; j < n - i; j++) {
                //Compare the current and the previous element
                if(isSmaller(arr,j,j - 1)) {
                    //the previous element is larger than current
                    //swap so larger element bubbles to end
                    swap(arr, j, j - 1);
                }
            }
        }
    }
    // used for swapping ith and jth elements of array
    public static void swap(int[] arr, int i, int j) {
        System.out.println("Swapping " + arr[i] + " and " + arr[j]);
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    // return true if ith element is smaller than jth element
    public static boolean isSmaller(int[] arr, int i, int j) {
        System.out.println("Comparing " + arr[i] + " and " + arr[j]);
        if (arr[i] < arr[j]) {
            return true;
        } else {
            return false;
        }
    }

    public static void print(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    public static void main(String[] args) throws Exception {
        Scanner scn = new Scanner(System.in);
        int n = scn.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = scn.nextInt();
        }
        bubbleSort(arr);
        print(arr);
    }

}
