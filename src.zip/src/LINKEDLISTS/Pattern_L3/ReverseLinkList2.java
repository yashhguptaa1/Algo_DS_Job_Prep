package LINKEDLISTS.Pattern_L3;

public class ReverseLinkList2 {
}
